function vOut = floor(v1)

vOut = v1;
vOut.value = floor(v1.value);
