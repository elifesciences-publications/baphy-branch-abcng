function v1 = uminus(v1)

v1.value = -v1.value;
