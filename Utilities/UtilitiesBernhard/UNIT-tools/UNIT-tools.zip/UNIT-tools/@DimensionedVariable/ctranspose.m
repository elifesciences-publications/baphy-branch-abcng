function vOut = ctranspose(v1)

vOut = v1;
vOut.value = v1.value';
