function vOut = sqrt(v1)

vOut = v1;
vOut.value = sqrt(v1.value);
vOut.exponents = v1.exponents/2;