function vOut = median(v1)

vOut = v1;
vOut.value = median(v1.value);
