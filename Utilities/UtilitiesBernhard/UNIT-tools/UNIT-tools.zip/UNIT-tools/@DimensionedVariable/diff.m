function v1= diff(v1)

v1.value = diff(v1.value);
