function outSize = size(v1)

outSize = size(v1.value);
