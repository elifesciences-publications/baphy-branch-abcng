function vOut = imag(v1)

vOut = v1;
vOut.value = imag(v1.value);
