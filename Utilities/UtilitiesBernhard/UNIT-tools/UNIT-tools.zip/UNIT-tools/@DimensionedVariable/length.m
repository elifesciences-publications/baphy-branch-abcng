function NPoints = length(v1)
NPoints = length(v1.value);
