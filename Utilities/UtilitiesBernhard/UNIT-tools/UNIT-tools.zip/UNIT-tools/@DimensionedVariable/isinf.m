function indexOut = isinf(v1)

indexOut = isinf(v1.value);
