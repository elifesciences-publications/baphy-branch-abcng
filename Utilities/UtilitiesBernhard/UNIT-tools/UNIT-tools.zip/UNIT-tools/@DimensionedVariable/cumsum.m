function v1 = cumsum(v1)

v1.value = cumsum(v1.value);
