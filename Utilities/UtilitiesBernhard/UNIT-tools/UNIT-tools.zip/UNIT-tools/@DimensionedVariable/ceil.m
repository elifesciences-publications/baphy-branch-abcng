function v1 = ceil(v1)

v1.value = ceil(v1.value);
