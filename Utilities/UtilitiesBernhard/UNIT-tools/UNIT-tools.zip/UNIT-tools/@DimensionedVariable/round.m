function vOut = round(v1)

vOut = v1;
vOut.value = round(v1.value);
