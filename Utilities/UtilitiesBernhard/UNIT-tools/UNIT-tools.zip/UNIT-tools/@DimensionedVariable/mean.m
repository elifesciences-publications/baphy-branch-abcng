function v1 = mean(v1)

v1.value = mean(v1.value);
