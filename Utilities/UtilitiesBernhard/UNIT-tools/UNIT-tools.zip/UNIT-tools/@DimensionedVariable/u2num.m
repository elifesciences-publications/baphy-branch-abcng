function value = u2num(inV)
value = inV.value;