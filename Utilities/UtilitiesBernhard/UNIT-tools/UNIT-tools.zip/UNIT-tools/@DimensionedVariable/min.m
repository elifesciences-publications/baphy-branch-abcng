function vOut = min(v1)

vOut = v1;
vOut.value = min(v1.value);
