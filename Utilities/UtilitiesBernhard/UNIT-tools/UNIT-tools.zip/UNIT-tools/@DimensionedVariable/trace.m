function vOut = trace(v1)

vOut = v1;
vOut.value = trace(v1.value);
