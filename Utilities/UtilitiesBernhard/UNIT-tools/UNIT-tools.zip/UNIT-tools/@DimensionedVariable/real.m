function vOut = real(v1)

vOut = v1;
vOut.value = real(v1.value);
