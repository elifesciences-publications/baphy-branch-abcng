function vOut = std(v1)

vOut = v1;
vOut.value = std(v1.value);
