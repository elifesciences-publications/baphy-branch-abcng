function vOut = diag(v1)

vOut = v1;
vOut.value = diag(v1.value);
