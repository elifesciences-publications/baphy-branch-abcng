function vOut = transpose(v1)

vOut = v1;
vOut.value = v1.value.';
