function vOut = max(v1)

vOut = v1;
vOut.value = max(v1.value);
