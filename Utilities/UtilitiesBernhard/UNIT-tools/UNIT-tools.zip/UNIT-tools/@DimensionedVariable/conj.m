function vOut = conj(v1)

vOut = v1;
vOut.value = conj(v1.value);
