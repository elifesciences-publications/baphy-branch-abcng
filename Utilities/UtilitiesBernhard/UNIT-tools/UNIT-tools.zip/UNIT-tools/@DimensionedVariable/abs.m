function v1 = abs(v1)

v1.value = abs(v1.value);
