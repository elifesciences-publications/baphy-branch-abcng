function v1 = sum(v1)

v1.value = sum(v1.value);
